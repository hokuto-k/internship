"""
Mocha - maf utility functions and rules to use caffe

This module depends on:
    maflib (embedded into maf.py)
    piccolo (https://github.pfidev.jp/tabe/piccolo)
"""

# import dataset
# import log
import net
